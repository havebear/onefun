var server = {
    domain: "http://103.228.131.139:8080/index.php/api",
    uploadUrl: "http://103.228.131.139:8080/index.php/upload",
    url: "http://103.228.131.139:8080/",
}

var cache = {
    user: "_user",
    userid: "_userid",
    niclkname: "_niclkname",
    token: '_token'
}